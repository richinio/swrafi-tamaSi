//
//  QuizBrain.swift
//  Quizzler-iOS13
//
//  Created by Richard Jariashvili on 04/07/2020..
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import Foundation

struct QuizBrain {
    
    var questionNumber = 0
    var score = 0
    
    let quiz = [
        Question(q: "ლოქორას სისხლი მწვანეა ?.", a: "True"),
        Question(q: "ადამიანის მძვლების ერთი მეოთხედი ფეხებსია მოგცეული.", a: "True"),
        Question(q: "არის თუ არა ცხვირი საუკეთესო გემოს აღქმელი.", a: "True"),
        Question(q: "პანდა უფრო უფრო პატარა ვიდრე გრიზლი.", a: "True"),
        Question(q: "ყველაზე მაღალი მთა იალბუზია.", a: "False"),
        Question(q: "დედამიწაზე ყველა მკველი მწერია კოღო.", a: "True"),
        Question(q: "ჰერაკლე აქილევრის შვილია.", a: "False"),
        Question(q: "ჯოს ბეზოვსი ყველაზე მდიდარი ადამინია'.", a: "True"),
        Question(q: "მთვარე უფრო პატარა ვიდრე დედამიწა'.", a: "True"),
        Question(q: "ყველაზე ლამაზი დიდი უდაბნო ჩინეთშია.", a: "False"),
        Question(q: "ყველაზე დიდი მთა საქართველოშია.", a: "False"),
        Question(q: "სინგაპური ყველაზე მდიდარი ქვეყანა.", a: "True")
    ]
    
    func getQuestionText() -> String {
        return quiz[questionNumber].text
    }
    
    func getProgress() -> Float {
        return Float(questionNumber) / Float(quiz.count)
    }
    
    mutating func getScore() -> Int {
        return score
    }
    
     mutating func nextQuestion() {
        
        if questionNumber + 1 < quiz.count {
            questionNumber += 1
        } else {
            questionNumber = 0
        }
    }
    
    mutating func checkAnswer(userAnswer: String) -> Bool {
        if userAnswer == quiz[questionNumber].answer {
            score += 1
            return true
        } else {
            return false
        }
    }
}

